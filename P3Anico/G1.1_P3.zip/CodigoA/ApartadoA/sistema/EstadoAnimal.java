package sistema;/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author byani
 */
public enum  EstadoAnimal {
    //Enumeracion que da los diferentes estados posibles que puede tener un animal en el sistema
    DISPONIBLE,ADOPTADO,ENTRATAMIENTO
}
