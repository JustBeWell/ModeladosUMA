package sistema;

/**
 *
 * @author byani
 */
public enum  EstadoAnimal {
    //Enumeracion que da los diferentes estados posibles que puede tener un animal en el sistema
    DISPONIBLE,ADOPTADO,ENTRATAMIENTO
}
